# Introduction
Simple script for conferting input csv to conform to the 2 given templates

# Use
`python main.py *your .csv/.txt file* *name of the celltemplate output file* *name of the layerprio output file*`

or

`python3 main.py *your .csv/.txt file* *name of the celltemplate output file* *name of the layerprio output file*`